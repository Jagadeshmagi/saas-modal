import React from 'react';

export default class ErrorPage extends React.Component {
  render() {
    return (
      <div> Error: Page not found </div>
    );
  }
}