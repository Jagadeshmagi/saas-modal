import React from 'react';

export default class PartnersList extends React.Component {

  render() {
    return (
      <div>
        <h1 style={{marginLeft:'100px',marginTop:'100px'}}>Coming soon...</h1>
      </div>
    );
  }
}