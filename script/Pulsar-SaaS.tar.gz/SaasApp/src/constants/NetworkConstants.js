export const NetworkConstants = {
	API_SERVER : 'http://localhost:3000'
}